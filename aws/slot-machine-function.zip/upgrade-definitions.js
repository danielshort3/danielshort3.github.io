module.exports = require('./slot-config/upgrade-definitions.json');
